-- Product Table
CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    ProductName NVARCHAR(100),
    Description NVARCHAR(500),
    Price DECIMAL(10, 2),
    Category NVARCHAR(50),
    ManufacturingDate DATE,
    ExpiryDate DATE,
    Weight DECIMAL(10, 2),
    Color NVARCHAR(50),
    StockQuantity INT,
    IsActive BIT DEFAULT 1
);

-- Vendor Table
CREATE TABLE Vendors (
    VendorID INT IDENTITY(1,1) PRIMARY KEY,
    VendorName NVARCHAR(100),
    Address NVARCHAR(500),
    ContactNumber NVARCHAR(20),
    Email NVARCHAR(100)
);

-- Order Table
CREATE TABLE Orders (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT,
    VendorID INT,
    AuthenticationID INT, 
    Quantity INT,
    Comment NVARCHAR(100),
    OrderDate DATETIME DEFAULT GETDATE(),
    IsDelivered BIT DEFAULT 0,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (VendorID) REFERENCES Vendors(VendorID),
    FOREIGN KEY (AuthenticationID) REFERENCES AuthenticatedUsers(AuthenticationID)
);

-- Insert sample data into Products table
INSERT INTO Products (ProductName, Description, Price, Category, ManufacturingDate, ExpiryDate, Weight, Color, StockQuantity, IsActive)
VALUES 
('Smartphone X', 'High-end smartphone with advanced features', 699.99, 'Electronics', '2023-01-15', '2023-12-31', 0.3, 'Black', 150, 1),
('Smart TV', '4K Ultra HD Smart TV with built-in streaming services', 799.99, 'Electronics', '2023-02-10', '2024-02-10', 15.8, 'Silver', 50, 1),
('Laptop Pro', 'Powerful laptop for professional use', 1099.99, 'Electronics', '2023-03-05', '2024-03-05', 2.0, 'Gray', 100, 1),
('Wireless Earbuds', 'Bluetooth wireless earbuds with noise cancellation', 129.99, 'Electronics', '2023-04-20', '2023-10-20', 0.1, 'White', 200, 1),
('Denim Jeans', 'Classic denim jeans for casual wear', 39.99, 'Clothing', '2023-05-15', '2023-12-31', 0.5, 'Blue', 300, 1),
('Leather Boots', 'Genuine leather boots for men', 89.99, 'Footwear', '2023-06-10', '2024-06-10', 1.2, 'Brown', 120, 1),
('Fitness Tracker', 'Fitness tracker with heart rate monitoring', 49.99, 'Electronics', '2023-07-05', '2023-12-31', 0.2, 'Black', 80, 1);

-- Insert sample data into Vendors table
INSERT INTO Vendors (VendorName, Address, ContactNumber, Email)
VALUES 
('Electro Mart', '123 Tech Street, Techland', '1234567890', 'info@electromart.com'),
('Gadget Galaxy', '456 Gizmo Lane, Tech City', '9876543210', 'info@gadgetgalaxy.com'),
('Fashion House', '789 Style Street, Fashion City', '5678901234', 'info@fashionhouse.com'),
('Footwear Haven', '101 Boot Boulevard, Shoe Town', '3456789012', 'info@footwearhaven.com'),
('Home Appliance Hub', '111 Appliance Avenue, Home City', '6789012345', 'info@appliancehub.com'),
('Sports Gear Store', '222 Sports Street, Sport City', '7890123456', 'info@sportsgearstore.com'),
('Bookworm Corner', '333 Book Street, Book City', '8901234567', 'info@bookwormcorner.com');

-- Insert sample data into Orders table
INSERT INTO Orders (ProductID, VendorID,AuthenticationID, Quantity, Comment, IsDelivered)
VALUES 
(1, 1, 2, 3, 'Order for smartphones from Electro Mart', 0),
(2, 2, 1, 2, 'Order for smart TVs from Gadget Galaxy', 1),
(3, 3, 1, 1, 'Order for laptops from Fashion House', 0),
(4, 1, 3,  5, 'Order for wireless earbuds from Electro Mart', 0),
(5, 4, 1,  4, 'Order for denim jeans from Footwear Haven', 1),
(6, 5, 2, 2, 'Order for leather boots from Home Appliance Hub', 0),
(7, 6, 3, 3, 'Order for fitness trackers from Sports Gear Store', 0);

CREATE TABLE RegisteredUsers (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100) NOT NULL,
    PasswordHash NVARCHAR(200) NOT NULL,
    RegistrationDate DATETIME DEFAULT GETDATE(),
);


CREATE TABLE AuthenticatedUsers (
    AuthenticationID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    Username NVARCHAR(50),
    PasswordHash NVARCHAR(100),  -- Store the hashed password
    FOREIGN KEY (UserID) REFERENCES RegisteredUsers(UserID)
);

ALTER TABLE AuthenticatedUsers ADD Role NVARCHAR(50);

-- Insert authenticated users' data into Authentication table
INSERT INTO AuthenticatedUsers (UserID, Username, PasswordHash, Role)
VALUES (1, 'john_doe', 'hashedpassword123', 'User');

INSERT INTO AuthenticatedUsers (UserID, Username, PasswordHash, Role)
VALUES (2, 'alice_smith', 'hashedpassword456', 'User');

INSERT INTO AuthenticatedUsers (UserID, Username, PasswordHash, Role)
VALUES (3, 'bob_jackson', 'hashedpassword789', 'User');

INSERT INTO AuthenticatedUsers (UserID, Username, PasswordHash, Role)
VALUES (4, 'admin', 'Admin@123', 'Admin');

CREATE TABLE AdminUser (
    AdminID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(255),
    [Password] NVARCHAR(255),
    ProductID INT,
    VendorID INT,
    OrderID INT,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (VendorID) REFERENCES Vendors(VendorID),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

-- Insert data into AdminUser table
INSERT INTO AdminUser (Username, [Password])
VALUES ('admin', 'Admin@123');


Select * From RegisteredUsers
Select * From AuthenticatedUsers 
Select * From Orders
Select * From Products
Select * From Vendors

