﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FinalAssignment.CustomValidation
{
    /// <summary>
    /// Validation attribute to ensure the value is greater than another property.
    /// </summary>
    public class GreaterThanAttribute : ValidationAttribute
    {
        private readonly string _propertyName;

        /// <summary>
        /// Initializes a new instance of the <see cref="GreaterThanAttribute"/> class.
        /// </summary>
        /// <param name="propertyName">The name of the other property to compare against.</param>
        public GreaterThanAttribute(string propertyName)
        {
            _propertyName = propertyName;
        }

        #region ValidationResult Method
        /// <summary>
        /// Validates the specified value against another property value.
        /// </summary>
        /// <param name="value">The value to validate.</param>
        /// <param name="validationContext">The validation context.</param>
        /// <returns>Validation result.</returns>
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var property = validationContext.ObjectType.GetProperty(_propertyName);
            var manufacturingDate = property.GetValue(validationContext.ObjectInstance);

            if (value == null || manufacturingDate == null)
            {
                return ValidationResult.Success;
            }

            if ((DateTime)value > (DateTime)manufacturingDate)
            {
                return ValidationResult.Success;
            }

            return new ValidationResult(ErrorMessage);
        }
        #endregion
    }
}
