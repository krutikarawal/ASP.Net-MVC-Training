﻿using System.Web.Mvc;
using System.Web.Routing;

namespace Assignment_2.Filters
{
    /// <summary>
    /// Custom authorization filter to restrict access to actions based on session data.
    /// Redirects to the login page if the user is not authenticated.
    /// </summary>
    public class CustomAuthorizationFilter : ActionFilterAttribute, IActionFilter
    {
        /// <summary>
        /// Called before the action method is executed.
        /// Checks if the user is authenticated based on session data.
        /// Redirects to the login page if the user is not authenticated.
        /// </summary>
        /// <param name="filterContext">The filter context, which encapsulates information for using Action Filters.</param>

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var session = filterContext.HttpContext.Session;
            if (session == null || (session != null && session["Username"] == null))
            {
                filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary { { "controller", "Login" }, { "action", "Index" } });
            }
            base.OnActionExecuting(filterContext);
        }

    }
}