﻿using FinalAssignment.Models;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;

namespace FinalAssignment.CustomFilters
{
    /// <summary>
    /// Custom filter to authorize users based on their role.
    /// </summary>
    public class UserRoleAuthorizationFilte : ActionFilterAttribute, IActionFilter, IAuthorizationFilter
    {
        /// <summary>
        /// Gets or sets the allowed role for authorization.
        /// </summary>
        public string AllowedRole { get; set; }

        #region
        /// <summary>
        /// Called before the action method is invoked.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        public void OnAuthorization(AuthorizationContext filterContext)
        {
            ECommerceDBEntities userBD = new ECommerceDBEntities();
            var session = filterContext.HttpContext.Session;
            string userName = filterContext.HttpContext.Session["UserName"] as string;
            var userData = userBD.AuthenticatedUsers.Where(x => x.Username.ToLower() == userName).FirstOrDefault();

            var user = filterContext.HttpContext.User;
            if (userName != null)
            {
                if (userData.Role != "Admin")
                {
                    if (user.Identity.IsAuthenticated && user.IsInRole(AllowedRole))
                    {
                        filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary { { "controller", "AdminHandlingUserOrders" }, { "action", "Index" } });
                    }
                    else
                    {
                        filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary
                        {
                            { "controller", "Error" },
                            { "action", "GenericError" }
                        }
                        );

                    }
                }
            }
            else
            {
                filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary { { "controller", "Login" }, { "action", "Login" } });
            }
        }
        #endregion
    }
}
