﻿using FinalAssignment.Models;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;

namespace FinalAssignment.CustomFilters
{
    /// <summary>
    /// Custom Authorization Filter for Admin Role.
    /// </summary>
    public class AdminRoleAuthorizationFilter : ActionFilterAttribute, IActionFilter, IAuthorizationFilter
    {
        #region
        /// <summary>
        /// Gets or sets the allowed role for authorization.
        /// </summary>
        public string AllowedRole { get; set; }
        #endregion

        #region  Custom Authorization Method
        /// <summary>
        /// Called before the action method is invoked.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        public void OnAuthorization(AuthorizationContext filterContext)
        {
            string userName = filterContext.HttpContext.Session["UserName"] as string;
            if (userName != null)
            {
                try
                {
                    ECommerceDBEntities userDb = new ECommerceDBEntities();
                    var session = filterContext.HttpContext.Session;

                    var userData = userDb.AuthenticatedUsers.Where(x => x.Username.ToLower() == userName).FirstOrDefault();

                    var user = filterContext.HttpContext.User;
                    if (userData.Role != "User")
                    {
                        if (user.Identity.IsAuthenticated && user.IsInRole(AllowedRole))
                        {
                            filterContext.Result = new RedirectToRouteResult(
                                new RouteValueDictionary { { "controller", "Home" }, { "action", "Index" } });
                        }
                        else
                        {
                            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary
                        {
                            { "controller", "Error" },
                            { "action", "GenericError" }
                        });
                        }
                    }
                }
                catch (Exception ex)
                {                      
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary
                {
                    { "controller", "Login" },
                    { "action", "Login" }
                });
                    throw ex;
                }
            }
            else
            {
                filterContext.Result = new RedirectToRouteResult(
                                new RouteValueDictionary { { "controller", "Login" }, { "action", "Login" } });
            }
        }
        #endregion
    }
}
