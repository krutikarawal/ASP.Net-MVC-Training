﻿using FinalAssignment.CustomFilters;
using FinalAssignment.Models;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    [UserRoleAuthorizationFilte(AllowedRole = "user")]
    public class AdminHandlingUserOrdersController : Controller
    {
        private ECommerceDBEntities db = new ECommerceDBEntities();

        #region To Display the List
        /// <summary>
        /// To Display the List
        /// </summary>
        /// <returns>List of Orders</returns>
        // GET: AdminHandlingUserOrders
        public ActionResult Index()
        {
            // Retrieve orders including related entities (Product, Vendor, AuthenticatedUser)
            var orders = db.Orders.Include(o => o.Product).Include(o => o.Vendor).Include(o => o.AuthenticatedUser);
            return View(orders.ToList());
        }
        #endregion

        #region Details
        // GET: AdminHandlingUserOrders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }
        #endregion

        #region Edit
        // GET: AdminHandlingUserOrders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }

            // Populate dropdowns for Product, Vendor, and AuthenticatedUser with selected values
            ViewBag.ProductID = new SelectList(db.Products, "ProductID", "ProductName", order.ProductID);
            ViewBag.VendorID = new SelectList(db.Vendors, "VendorID", "VendorName", order.VendorID);
            ViewBag.AuthenticationID = new SelectList(db.AuthenticatedUsers, "AuthenticationID", "Username", order.AuthenticationID);
            return View(order);
        }

        // POST: AdminHandlingUserOrders/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OrderID,ProductID,VendorID,Quantity,Comment,OrderDate,IsDelivered,AuthenticationID")] Order order)
        {
            if (ModelState.IsValid)
            {
                // Update and save changes to the order
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            // If the model state is not valid, redisplay the form with dropdown values
            ViewBag.ProductID = new SelectList(db.Products, "ProductID", "ProductName", order.ProductID);
            ViewBag.VendorID = new SelectList(db.Vendors, "VendorID", "VendorName", order.VendorID);
            ViewBag.AuthenticationID = new SelectList(db.AuthenticatedUsers, "AuthenticationID", "Username", order.AuthenticationID);
            return View(order);
        }
        #endregion

        #region Delete
        // GET: AdminHandlingUserOrders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // POST: AdminHandlingUserOrders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Order order = db.Orders.Find(id);

            // Check if the order has already been delivered
            if (order != null && order.IsDelivered.GetValueOrDefault())
            {
                // Product is already delivered, show a toastr message
                TempData["ShowDeletionMessage"] = "Product is already delivered. Deletion not allowed.";

                // You can also pass a flag to indicate that toastr should be shown
                TempData["ShowToastr"] = true;

                return RedirectToAction("Index");
            }

            // If the order is not delivered, proceed with deletion
            db.Orders.Remove(order);
            db.SaveChanges();

            return RedirectToAction("Index");
        }
        #endregion

        // Dispose of the database context
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
