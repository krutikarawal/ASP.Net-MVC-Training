﻿using Assignment_2.Filters;
using FinalAssignment.CustomFilters;
using System;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    [AdminRoleAuthorizationFilter(AllowedRole = "admin")]
    [CustomAuthorizationFilter]
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]
    public class HomeController : Controller
    {
        #region Index
        /// <summary>
        /// Displays the home page.
        /// </summary>
        public ActionResult Index()
        {
            return View();
        }
        #endregion

        #region About
        /// <summary>
        /// Displays information about the application.
        /// </summary>
        public ActionResult About()
        {
            // Message to be displayed in the view
            ViewBag.Message1 = "At our Core, we're here for you ";

            return View();
        }
        #endregion

        #region Contact
        /// <summary>
        /// Displays the contact page.
        /// </summary>
        public ActionResult Contact()
        {
            // Message to be displayed in the view
            ViewBag.Message = "Your contact page.";

            return View();
        }
        #endregion

        [HandleError]
        public ActionResult Error()
        {
            var errorInfo = new HandleErrorInfo(new Exception("An error occurred."), "Controller", "Action");
            return View(errorInfo);
        }
    }
}
