﻿using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    #region ErrorController
    /// <summary>
    /// Controller responsible for handling errors.
    /// </summary>
    public class ErrorController : Controller
    {
        #region GenericError
        /// <summary>
        /// Action for displaying a generic error view.
        /// </summary>
        /// <returns>View for generic errors.</returns>
        // GET: Error
        public ActionResult GenericError()
        {
            return View();
        }
        #endregion

        #region NotFound
        /// <summary>
        /// Action for displaying a not found (404) error view.
        /// </summary>
        /// <returns>View for not found errors.</returns>
        public ActionResult NotFound()
        {
            return View();
        }
        #endregion
    }
    #endregion
}