﻿using Assignment_2.Filters;
using FinalAssignment.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    [CustomAuthorizationFilter]
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]
    /// <summary>
    /// Controller for managing vendors in the ECommerce system.
    /// </summary>
    public class VendorsController : Controller
    {
        private ECommerceDBEntities db = new ECommerceDBEntities();

        #region Index
        // GET: Vendors
        public ActionResult Index()
        {
            /// <summary>
            /// Displays a list of all vendors.
            /// </summary>
            return View(db.Vendors.ToList());
        }
        #endregion

        #region Details
        // GET: Vendors/Details/5
        public ActionResult Details(int? id)
        {
            /// <summary>
            /// Displays details of a specific vendor.
            /// </summary>
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vendor vendor = db.Vendors.Find(id);
            if (vendor == null)
            {
                return HttpNotFound();
            }
            return View(vendor);
        }
        #endregion

        #region Create
        // GET: Vendors/Create
        public ActionResult Create()
        {
            /// <summary>
            /// Displays the form to create a new vendor.
            /// </summary>
            return View();
        }

        // POST: Vendors/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "VendorID,VendorName,Address,ContactNumber,Email")] Vendor vendor)
        {
            /// <summary>
            /// Handles the creation of a new vendor.
            /// </summary>
            if (ModelState.IsValid)
            {
                db.Vendors.Add(vendor);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(vendor);
        }
        #endregion

        #region Edit
        // GET: Vendors/Edit/5
        public ActionResult Edit(int? id)
        {
            /// <summary>
            /// Displays the form to edit a specific vendor.
            /// </summary>
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vendor vendor = db.Vendors.Find(id);
            if (vendor == null)
            {
                return HttpNotFound();
            }
            return View(vendor);
        }

        // POST: Vendors/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "VendorID,VendorName,Address,ContactNumber,Email")] Vendor vendor)
        {
            /// <summary>
            /// Handles the editing of a vendor.
            /// </summary>
            if (ModelState.IsValid)
            {
                db.Entry(vendor).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(vendor);
        }
        #endregion

        #region Delete
        // GET: Vendors/Delete/5
        public ActionResult Delete(int? id)
        {
            /// <summary>
            /// Displays the form to confirm the deletion of a vendor.
            /// </summary>
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vendor vendor = db.Vendors.Find(id);
            if (vendor == null)
            {
                return HttpNotFound();
            }
            return View(vendor);
        }

        // POST: Vendors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            /// <summary>
            /// Handles the deletion of a vendor.
            /// </summary>
            Vendor vendor = db.Vendors.Find(id);
            db.Vendors.Remove(vendor);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        #endregion

        // Dispose of the database context
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        [HandleError]
        public ActionResult Error()
        {
            var errorInfo = new HandleErrorInfo(new Exception("An error occurred."), "Controller", "Action");
            return View(errorInfo);
        }
    }
}
