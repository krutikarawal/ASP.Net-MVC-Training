﻿using FinalAssignment.Models;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;


namespace FinalAssignment.Controllers
{
    public class LoginController : Controller
    {
        #region Login
        /// <summary>
        /// POST: Login
        /// Handles the login form submission.
        /// </summary>
        /// <param name="user">The authenticated user.</param>
        /// <returns>Returns a ActionResult based on the login result.</returns>
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Login")]
        public ActionResult Login(AuthenticatedUser user)
        {
            if (ModelState.IsValid)
            {
                ECommerceDBEntities db = new ECommerceDBEntities();
                var credentials = db.AuthenticatedUsers
                    .Where(x => x.Username.ToLower() == user.Username.ToLower() &&
                                x.PasswordHash == user.PasswordHash)
                    .FirstOrDefault();

                string userRole = credentials?.Role;

                if (userRole == "Admin")
                {
                    if (credentials != null)
                    {
                        Session["UserId"] = credentials.UserID;
                        Session["Username"] = credentials.Username;
                        FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);

                        // Toastr message for successful login
                        TempData["ToastrMessage"] = "Login successful! Welcome, " + user.Username + "!";
                        TempData.Keep();
                        return RedirectToAction("Index", "AdminHandlingUserOrders");
                    }
                    else
                    {
                        Session["UserId"] = null;
                        Session["Username"] = null;
                        Session.Abandon();
                        TempData["ToastrMessage"] = "Invalid Username or password";
                        TempData.Keep();
                        return View();
                    }
                }
                else if (userRole == "User")
                {
                    if (credentials != null)
                    {
                        Session["UserId"] = credentials.UserID;
                        Session["Username"] = credentials.Username;
                        FormsAuthentication.SetAuthCookie(user.Username.ToLower(), false);

                        // Toastr message for successful login
                        TempData["ToastrMessage"] = "Login successful! Welcome, " + user.Username + "!";
                        TempData.Keep();
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        Session["UserId"] = null;
                        Session["Username"] = null;
                        Session.Abandon();
                        TempData["ToastrMessage"] = "Invalid Username or password";
                        TempData.Keep();
                        return View();
                    }
                }
            }
            return View();
        }
        #endregion

        #region Logout
        /// <summary>
        /// GET: Logout
        /// Logs out the user and redirects to the login page.
        /// </summary>
        /// <returns>Returns a ActionResult for the logout process.</returns>
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();

            // Toastr message for successful logout
            TempData["ToastrMessage"] = "Logout successful!";
            TempData.Keep();
            System.Threading.Thread.Sleep(1000);
            // Redirect to the login page with a unique parameter (cache buster)
            return RedirectToAction("Login", new { cacheBuster = System.DateTime.Now.Ticks });
        }
        #endregion

    }
}
