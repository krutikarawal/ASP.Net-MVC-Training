﻿using FinalAssignment.Models;
using System;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    public class RegisterController : Controller
    {
        #region
        /// <summary>
        /// Displays the registration form.
        /// </summary>
        /// <returns>The registration view.</returns>
        public ActionResult Register()
        {
            return View();
        }

        /// <summary>
        /// Handles the registration form submission.
        /// </summary>
        /// <param name="model">The model containing user registration information.</param>
        /// <returns>Redirects to the login page if registration is successful; otherwise, returns the registration view with errors.</returns>
        [HttpPost]
        public ActionResult Register(RegisteredUser model)
        {
            ECommerceDBEntities db = new ECommerceDBEntities();

            if (ModelState.IsValid)
            {
                try
                {
                    
                    RegisteredUser newRegisteredUser = new RegisteredUser
                    {
                        Username = model.Username,
                        Email = model.Email,
                        PasswordHash = model.PasswordHash,
                        RegistrationDate = DateTime.Now,
                    };

                    
                    db.RegisteredUsers.Add(newRegisteredUser);
                    db.SaveChanges();

                    
                    AuthenticatedUser newAuthenticatedUser = new AuthenticatedUser
                    {
                        UserID = newRegisteredUser.UserID,
                        Username = newRegisteredUser.Username,
                        PasswordHash = newRegisteredUser.PasswordHash,
                        Role = "User"
                    };

                    
                    db.AuthenticatedUsers.Add(newAuthenticatedUser);
                    db.SaveChanges();

                    
                    return RedirectToAction("Login", "Login");
                }
                catch (Exception ex)
                {
                    
                    ModelState.AddModelError(string.Empty, "An error occurred while processing your request. Please try again later.");
                    throw ex;
                }
            }

           
            return View(model);
        }
    }
}
#endregion