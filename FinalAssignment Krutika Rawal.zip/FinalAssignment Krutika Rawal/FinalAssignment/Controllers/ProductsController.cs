﻿using Assignment_2.Filters;
using FinalAssignment.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    [CustomAuthorizationFilter]
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]
    public class ProductsController : Controller
    {
        private ECommerceDBEntities db = new ECommerceDBEntities();

        #region Index
        /// <summary>
        /// Displays a list of all products.
        /// </summary>
        /// <returns>View with a list of products</returns>
        public ActionResult Index()
        {
            return View(db.Products.ToList());
        }
        #endregion

        #region Details
        /// <summary>
        /// Displays details of a specific product.
        /// </summary>
        /// <param name="id">The ID of the product</param>
        /// <returns>View with product details</returns>
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }
        #endregion

        #region Create
        /// <summary>
        /// Displays the form to create a new product.
        /// </summary>
        /// <returns>View with the create product form</returns>
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Creates a new product.
        /// </summary>
        /// <param name="product">The product to be created</param>
        /// <returns>Redirects to the product index on successful creation</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductID,ProductName,Description,Price,Category,ManufacturingDate,ExpiryDate,Weight,Color,StockQuantity,IsActive")] Product product)
        {
            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product);
        }
        #endregion

        #region Edit
        /// <summary>
        /// Displays the form to edit a specific product.
        /// </summary>
        /// <param name="id">The ID of the product</param>
        /// <returns>View with the edit product form</returns>
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        /// <summary>
        /// Edits a specific product.
        /// </summary>
        /// <param name="product">The product with updated information</param>
        /// <returns>Redirects to the product index on successful edit</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProductID,ProductName,Description,Price,Category,ManufacturingDate,ExpiryDate,Weight,Color,StockQuantity,IsActive")] Product product)
        {
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Displays the form to delete a specific product.
        /// </summary>
        /// <param name="id">The ID of the product</param>
        /// <returns>View with the delete product form</returns>
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        /// <summary>
        /// Deletes a specific product.
        /// </summary>
        /// <param name="id">The ID of the product to be deleted</param>
        /// <returns>Redirects to the product index on successful deletion</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Product product = db.Products.Find(id);
            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        #endregion

        // Dispose of the database context
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        [HandleError]
        public ActionResult Error()
        {
            var errorInfo = new HandleErrorInfo(new Exception("An error occurred."), "Controller", "Action");
            return View(errorInfo);
        }
    }
}
