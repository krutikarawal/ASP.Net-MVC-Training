﻿using Assignment_2.Filters;
using FinalAssignment.Models;
using System;
using System.Data;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{

    [CustomAuthorizationFilter]
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]
    /// <summary>
    /// Controller responsible for handling user orders.
    /// </summary>
    public class UserOrdersController : Controller
    {
        private readonly ECommerceDBEntities db = new ECommerceDBEntities();

        #region
        /// <summary>
        /// Displays a list of orders for the current user.
        /// </summary>
        /// <returns>The view containing the list of user orders.</returns>
        public ActionResult Index()
        {
            
            var userName = Session["Username"];
            
            var orders = db.Orders.Where(x => x.AuthenticatedUser.Username == userName).ToList();
            return View(orders);
        }
        #endregion

        #region
        /// <summary>
        /// Displays details for a specific order.
        /// </summary>
        /// <param name="id">The ID of the order to display details for.</param>
        /// <returns>The view containing details for the specified order.</returns>
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }
        #endregion

        #region
        /// <summary>
        /// Displays the form for creating a new order.
        /// </summary>
        /// <returns>The view containing the order creation form.</returns>
        public ActionResult Create()
        {
            // Populate dropdowns for Product, Vendor, and AuthenticatedUser
            ViewBag.ProductID = new SelectList(db.Products, "ProductID", "ProductName");
            ViewBag.VendorID = new SelectList(db.Vendors, "VendorID", "VendorName");
            ViewBag.AuthenticationID = new SelectList(db.AuthenticatedUsers, "AuthenticationID", "Username");
            return View();
        }
        #endregion

        #region
        /// <summary>
        /// Handles the HTTP POST request for creating a new order.
        /// </summary>
        /// <param name="order">The order information to be created.</param>
        /// <returns>Redirects to the user orders index if successful, otherwise displays an error.</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "OrderID,ProductID,VendorID,Quantity,Comment,OrderDate,IsDelivered")] Order order)
        {
            if (ModelState.IsValid)
            {
                
                var userName = Session["Username"]?.ToString();

                
                if (!string.IsNullOrEmpty(userName))
                {
                    
                    var user = db.AuthenticatedUsers.FirstOrDefault(x => x.Username == userName);

                    
                    if (user != null)
                    {
                       
                        order.AuthenticationID = user.AuthenticationID;

                        
                        db.Orders.Add(order);
                        db.SaveChanges();

                        return RedirectToAction("Index", "UserOrders");
                    }
                }

                
                return RedirectToAction("Error", "Home");
            }

            
            ViewBag.ProductID = new SelectList(db.Products, "ProductID", "ProductName", order.ProductID);
            ViewBag.VendorID = new SelectList(db.Vendors, "VendorID", "VendorName", order.VendorID);

            
            return View(order);
        }
        #endregion

        #region
        /// <summary>
        /// Displays the confirmation page for deleting a specific order.
        /// </summary>
        /// <param name="id">The ID of the order to be deleted.</param>
        /// <returns>The view containing the order details and confirmation for deletion.</returns>
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }
        #endregion

        #region
        /// <summary>
        /// Handles the HTTP POST request for deleting a specific order.
        /// </summary>
        /// <param name="id">The ID of the order to be deleted.</param>
        /// <returns>Redirects to the user orders index if successful, otherwise displays an error.</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Order order = db.Orders.Find(id);

            // Check if the order has already been delivered
            if (order != null && order.IsDelivered.GetValueOrDefault())
            {
                // Product is already delivered, show an error message
                TempData["ShowMessage"] = "Product is already delivered. Deletion not allowed.";
                return View("Delete", order);
            }

            // If the order is not delivered, proceed with deletion
            db.Orders.Remove(order);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        #endregion

        #region
        /// <summary>
        /// Disposes of the database context.
        /// </summary>
        /// <param name="disposing">True if disposing, false otherwise.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        #endregion

        [HandleError]
        public ActionResult Error()
        {
            var errorInfo = new HandleErrorInfo(new Exception("An error occurred."), "Controller", "Action");
            return View(errorInfo);
        }
    }
}
